package com.example.latihanuts

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn_cal.setOnClickListener {
            val intent = Intent(this, CalActivity::class.java)
            startActivity(intent)
        }


        btn_about.setOnClickListener {
            val namaku = "Luqman Syafi Rabbani"
            val email = "lukyrabbani@gmail.com"
            val phone = "089607558247"

            val about = Intent(this, AboutActivity::class.java)
            about.putExtra("Namaku", namaku)
            about.putExtra("Email", email)
            about.putExtra("Phone", phone)
            startActivity(about)
        }

        btn_form.setOnClickListener {
            val beritaku = "Silo ditutup Dinas Pendidikan Jember. Sekolah itu adalah SDN Sidomulyo 08 dan SDN Curahtakir 05. Penutupan dilakukan karena dua sekolah itu sepi peminat. “Itu kami tutup karena peserta didik relatif sangat sedikit,” kata Kepala Dinas Pendidikan Kabupaten Jember Edy Budy Susilo usai rapat dengar pendapat dengan Komisi D DPRD Jember, Rabu (12/11/2020). Edy menjelaskan, SDN Mulyorejo tak punya pelajar lagi. Sebab, dua pelajar yang sebelumnya bertahan sudah dinyatakan lulus"

            val berita = Intent(this, Berita2Activity::class.java)
            berita.putExtra("Berita", beritaku)
            startActivity(berita)
        }
    }
}
